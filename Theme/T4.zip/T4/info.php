<?php

return array(
    //模版名
    'name' => 'T4',
    //别名
    'title' => '仿TS4.0风格',
    //版本号
    'version' => '1.0.0',
    //是否商业模版,1是，0，否
    'is_com' => 0,
    //模版描述
    'summary' => '简单模仿T4的设计风格。',
    //开发者
    'developer' => '郑恒盛',
    //开发者网站
    'website' => 'http://www.ourstu.com',
);